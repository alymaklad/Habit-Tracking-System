---
name: Vellum & Intention
colors:
  surface: '#fff8f3'
  surface-dim: '#e0d9d2'
  surface-bright: '#fff8f3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#faf2eb'
  surface-container: '#f4ede6'
  surface-container-high: '#eee7e0'
  surface-container-highest: '#e9e1db'
  on-surface: '#1e1b17'
  on-surface-variant: '#424844'
  inverse-surface: '#33302c'
  inverse-on-surface: '#f7efe9'
  outline: '#727973'
  outline-variant: '#c2c8c2'
  surface-tint: '#466554'
  primary: '#284636'
  on-primary: '#ffffff'
  primary-container: '#3f5e4d'
  on-primary-container: '#b3d6c0'
  inverse-primary: '#acceb9'
  secondary: '#914b2c'
  on-secondary: '#ffffff'
  secondary-container: '#fda27d'
  on-secondary-container: '#77361a'
  tertiary: '#334156'
  on-tertiary: '#ffffff'
  tertiary-container: '#4a586e'
  on-tertiary-container: '#c0cee8'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c8ebd5'
  primary-fixed-dim: '#acceb9'
  on-primary-fixed: '#012113'
  on-primary-fixed-variant: '#2e4d3d'
  secondary-fixed: '#ffdbce'
  secondary-fixed-dim: '#ffb598'
  on-secondary-fixed: '#370e00'
  on-secondary-fixed-variant: '#743418'
  tertiary-fixed: '#d5e3fe'
  tertiary-fixed-dim: '#b9c7e1'
  on-tertiary-fixed: '#0d1c2f'
  on-tertiary-fixed-variant: '#3a475d'
  background: '#fff8f3'
  on-background: '#1e1b17'
  surface-variant: '#e9e1db'
typography:
  display-hero:
    fontFamily: Newsreader
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Newsreader
    fontSize: 36px
    fontWeight: '400'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Newsreader
    fontSize: 26px
    fontWeight: '400'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Newsreader
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-italic:
    fontFamily: Newsreader
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-stamp:
    fontFamily: Newsreader
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.08em
  label-ui:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  caption:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 15px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-mobile: 0.75rem
  margin: 2.5rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system draws its soul from the intimate ritual of journaling: tactile heavy-weight cotton paper, hand-pressed botanical inks, margin notes, and physical artifacts collected over time. It represents a deliberate departure from clinical, dopamine-engineered productivity software. Instead of gamified rings and fluorescent notifications, the interface feels quiet, contemplative, and grounding.

The visual style is **Tactile Editorial Minimalist**. It unites literary publishing traditions with warm, physical paper goods. Surfaces carry the subtle tooth and warmth of vellum and unbleached card stock, while interactive states simulate physical friction—gentle debossing, deckled edges, washi-tape tabs, and physical stamps. Typography is treated as ink upon paper, carrying clear typographic hierarchy, generous literary measure, and breathing room. The emotional response is one of pause, intentionality, quiet accomplishment, and unhurried personal evolution.

## Colors

The color palette mirrors natural mineral pigments, botanicals, and paper stock aged under natural light.

- **Primary (`#3F5E4D` — Laurel Forest):** Used for forward movement, continuous habits, active states, and growth indicators. Represents vitality, consistency, and calm persistence.
- **Secondary (`#BA6B4A` — Raw Ochre / Terracotta):** Used for breakthrough milestones, intention pins, primary call-to-actions, and streak markers. Provides warmth and physical gravitas.
- **Tertiary (`#4A586E` — Slate Indigo):** Reserved for reflective moments, evening reviews, audio memos, and historical archive stamps.
- **Neutral (`#24211D` — Carbon Ink):** The anchor for high-legibility typographic hierarchy. Supported by `#3E3832` (Diluted Ink) for secondary reading copy and metadata.

### Surface Tiers & Environment
- **Canvas Base (`#FBF8F3`):** Delicate vellum cream serving as the deep background layer.
- **Surface Elevation (`#F6F1EA`):** Bound cotton sheet layer for primary content blocks and journal entries.
- **Surface Recessed / Docket (`#EFE8DD`):** Pressed pulp cardboard for inset containers, metadata shelves, and passive backgrounds.
- **Rules & Margin Guides (`#E3DACB`):** Fine ruled borders mimicking ledger printings.

## Typography

The typographic strategy pairs the literary, human warmth of **Newsreader** with the soft, modern legibility of **Plus Jakarta Sans**.

- **Editorial Headings (Newsreader):** Headlines evoke classic book typesetting. Optical sizing should favor warm italicization for intimate self-reflection prompts and milestones.
- **Instrumental Body (Plus Jakarta Sans):** Selected for its humanist geometry and open counters, ensuring frictionless reading on small viewports while maintaining an organic, friendly cadence.
- **Reflective Accents (`body-italic`):** Used for user quotes, prompt guides, micro-reflections, and date entries.
- **Stamp & Notation (`label-stamp`):** Set in uppercase with wide tracking to evoke inked rubber stamps, docket numbering, and bookplate notations.

## Layout & Spacing

The layout philosophy mirrors an open, bound desk journal. Content flows through disciplined vertical rhythm governed by a baseline grid of 4px and a standard modular step of 8px.

### Form Factors & Adaptation
- **Mobile (<640px):** Single-column layout anchored with generous lateral padding (`1.25rem`). Cards feel like bound pocket-notebook pages running flush or with minimal safe margins.
- **Tablet (641px–1024px):** 6-column fluid structure. Allows side-by-side presentation of habit tallies alongside daily long-form reflections.
- **Desktop (>1025px):** 12-column fixed-max layout (capped at 1120px) centered within an expansive vellum void (`#FBF8F3`). The primary entry view mimics an open folio with metadata, habits, and timeline tracking structured in the left marginalia.

Vertical separation prioritizes breathing room (`space-xl` between modular sections) to induce calm focus, while intra-component clusters remain tightly coupled (`space-xs` and `space-sm`).

## Elevation & Depth

Visual hierarchy rejects digital glow, bright dropshadows, or translucent synthetic glass. Depth is achieved via **Paper Stock Stratification** and **Ambient Sunlit Diffusions**:

1. **The Physical Sheet (Flat Elevation):**
   Components sit directly on `#FBF8F3` delineated only by a 1px hairline border of `#E3DACB` (Notebook Rule).
2. **Card Stock Lift (Resting Elevation):**
   Cards mimic 300gsm paper stock sitting on a desk under diffuse natural morning light:
   - Primary Shadow: `0 2px 4px 0 rgba(36, 33, 29, 0.04)`
   - Ambient Shadow: `0 8px 24px -4px rgba(36, 33, 29, 0.07)`
   - Border: 1px solid `#EFE8DD`
3. **The Pinned/Affixed Layer (Floating Elevation):**
   Used for toolbars, modals, floating action bars, and active drag states:
   - Primary Shadow: `0 12px 32px -6px rgba(36, 33, 29, 0.12)`
   - Surface Tint: `#FFFFFF` with 2% `#FBF8F3` warm-mix opacity.
4. **Pressed/Debossed Layer (Inset Depth):**
   Used for habit checkboxes, input wells, and timeline tracks:
   - Inner Shadow: `inset 0 1px 3px 0 rgba(36, 33, 29, 0.06)`
   - Background: `#EFE8DD`

## Shapes

The shape system adopts soft, organic corners reminiscent of heavy cut paper and deckled edges rather than synthetic rounds:

- **Base Radius (`0.25rem` / `4px`):** Small elements, chips, stamps, and tags.
- **Medium Radius (`0.5rem` / `8px`):** Interactive buttons, input fields, and standard cards.
- **Large Radius (`0.75rem` / `12px`):** Modals, daily log folios, and bottom sheets.
- **Stamp & Seal Shapes:** Select milestone stamps utilize jagged or scalloped edge masks, simulating perforated edges or circular wax stamp impressions.

## Components

### Buttons & Interactive Touchpoints
- **Primary Action (The Wax Stamp):** Rich Ochre (`#BA6B4A`) or Deep Forest (`#3F5E4D`) fill with pale vellum text (`#FBF8F3`). Flat base with a 1px tonal border (`rgba(36, 33, 29, 0.08)`). Press state produces an organic inset compression rather than a scale-down effect.
- **Secondary Action (The Ruled Line):** Transparent background with a 1px solid `#3E3832` border, filled with charcoal ink text. Hover gently shifts the background to `#EFE8DD`.
- **Ghost Action:** Plain typographic button with a subtle dashed underline accent.

### Cards & Folios
- Built from `#F6F1EA` paper stock.
- Headers are separated with a hairline rule (`#E3DACB`).
- Optional decorative polaroid washi-tape accent at top center (`#EFE8DD` translucent strip with rough borders) for pinned focus habits or high-priority reflections.

### Habit Trackers & Checkboxes
- Replaces generic digital checkmarks with hand-drawn physical metaphors: an ink dot (`•`), a deliberate diagonal slash (`/`), or an ink-filled square.
- Completed states transition from a hollow debossed box (`#EFE8DD`) to a solid Laurel Green (`#3F5E4D`) or Ochre (`#BA6B4A`) fill with an organic ink-bleed transition.

### Input Fields & Reflection Prompts
- Text areas ditch boxed clinical borders in favor of warm, ruled horizontal lines reminiscent of ruled legal pads or French-ruled notebooks (`#E3DACB` underlines spaced consistently at 28px).
- Placeholder text is set in `Newsreader` italic with diluted ink tone (`#8E877E`).
- Active focus state highlights the baseline in Laurel Forest (`#3F5E4D`) with zero outer ring glow.

### Chips, Tags & Badges
- Modeled after stamped labels or archival library index cards.
- Set in uppercase `label-stamp` font.
- Backgrounds use muted washes: Sage tint (`#EDF2EE`), Ochre tint (`#F9F1EB`), or Slate tint (`#EFF2F5`), each paired with their respective deep solid ink for text.

### Reflection Stamps & Milestone Seals
- Dedicated circular, hexagonal, or ribbon-tail badge components.
- Borders feature double-line rings with center-aligned Roman numerals, dates, or milestone notations, rotated organically between `-1.5deg` and `+1.5deg` to maintain authentic physical variety.